package edu.kit.informatik;

/**
 * @author Michael Finger
 * @version 1.0.0
 */
public class Agent extends User {

    public Agent(String firstname, String lastname, String personalnumber, String password) {
        super(firstname, lastname, personalnumber, password);
    }
    
}
