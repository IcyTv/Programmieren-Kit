package edu.kit.informatik;

/**
 * @author Michael Finger
 * @version 1.0.0
 */
public class Mailman extends User {

    public Mailman(String firstname, String lastname, String personalnumber, String password) {
        super(firstname, lastname, personalnumber, password);
    }
    
}
