public class Componist extends Artist {
    public Componist(String name, String lastName, Date firstWorkDate) {
        super(name, lastName, firstWorkDate);
    }
}
