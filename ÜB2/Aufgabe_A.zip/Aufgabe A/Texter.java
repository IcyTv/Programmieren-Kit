public class Texter extends Artist {
    public Texter(String name, String lastName, Date firstWorkDate) {
        super(name, lastName, firstWorkDate);
    }
}