public class Label {
    private final String name;
    private final Contact contacts;
    private final Date generationDate;

    public Label(String name, Contact contacts, Date generationDate) {
        this.name = name;
        this.contacts = contacts;
        this.generationDate = generationDate;
    }
}