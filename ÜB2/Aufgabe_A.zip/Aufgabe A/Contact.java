public class Contact {
    public final String street;
    public final String city;
    public final int postCode;

    public Contact(String street, String city, int postCode) {
        this.street = street;
        this.city = city;
        this.postCode = postCode;
    }
}
