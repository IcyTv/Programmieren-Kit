public class Interpret extends Artist {
    public Interpret(String name, String lastName, Date firstWorkDate) {
        super(name, lastName, firstWorkDate);
    }
}
