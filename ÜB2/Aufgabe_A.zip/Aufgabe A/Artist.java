public class Artist {
    private final String name;
    private final String lastName;
    private final Date firstWorkDate;

    public Artist(String name, String lastName, Date firstWorkDate) {
        this.name = name;
        this.lastName = lastName;
        this.firstWorkDate = firstWorkDate;
    }
}