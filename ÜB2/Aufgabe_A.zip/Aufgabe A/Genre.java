public enum Genre {
    Rock, Pop, Punk, HipHop, Schlager, Jazz, Blues, Klassik, Reggae
}
