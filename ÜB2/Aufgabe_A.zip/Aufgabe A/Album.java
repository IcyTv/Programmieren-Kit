public class Album {
    private final String title;
    private final Interpret  interpret;
    private final Date dateOfRelease;
    private final Label label;
    private final int songs;
    private final Genre genre;

    public Album(String title, Interpret interpret, Date dateOfRelease, Label label, int songs, Genre genre) {
        this.title = title;
        this.interpret = interpret;
        this.dateOfRelease = dateOfRelease;
        this.label = label;
        this.songs = songs;
        this.genre = genre;
    }
}