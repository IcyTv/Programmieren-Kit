public class Song {
    private final String title;
    private final Interpret interpret;
    private final Componist componist;
    private final Texter texter;
    private final int minutes;
    private final int seconds;

    public Song(String title, Interpret interpret, Componist componist, Texter texter, int minute, int sseconds) {
        this.title = title;
        this.interpret = interpret;
        this.componist = componist;
        this.texter = texter;
        this.minutes = minute;
        this.seconds = sseconds;
    }
}